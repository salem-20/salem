# 1. تثبيت المتطلبات
pip install -r requirements.txt

# 2. إنشاء التهجيرات
python manage.py makemigrations

# 3. تطبيق التهجيرات
python manage.py migrate

# 4. إنشاء